# Curso_python_senai
Repositorio do curso de python feito no Senai Marcio Bagueira Leal
