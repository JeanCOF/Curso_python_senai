def maior_num(nums):
    for i in range(0,2):
        num=float(input(f"Informe o Numero {i+1}: "))
        nums.append(num)

        maior = min(nums)
    return maior
nums = []          

print("O maior numero da sequencia é {}".format(maior_num(nums)))