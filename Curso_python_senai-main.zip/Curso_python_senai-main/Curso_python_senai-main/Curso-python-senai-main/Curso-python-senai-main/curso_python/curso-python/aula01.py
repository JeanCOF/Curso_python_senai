print("hello world")
print("123")
num=10
print("O numero e:",num)
print("Ola!")
print("5")
print("O meu nome e joao")
print("Python e legal!")
print("1, 2, 3")
print('"Hoje e um bom dia"')
frase="Aprendendo Python... \n"
print(frase*3)
num1= 2
num2= 3
x = num1 + num2
print("a Soma de",num1,"e",num2,"e",x)
print('Gostei disso',"!")
texto= "Cachorro".lower()
print(texto)
print("Estou aprendendo","Python")
print("Feliz ","Aniversario")
print("Bom","Trabalho")
num3= -10
print(num3)
from datetime import datetime
print("Hoje e:",datetime.today().strftime("%d-%A-%m-%B"))
