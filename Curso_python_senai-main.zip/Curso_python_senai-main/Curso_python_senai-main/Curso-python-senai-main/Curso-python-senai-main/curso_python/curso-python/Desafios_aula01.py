#ex 1
print("O primeiro programa a gente nunca esquece")
#ex 2
print(
    "Jean Carlo de Oliveira Filho\n"
    "Av.Dr. Abrãao Brickman 1220, 14407.310\n"
    "(16)993028500"
)
#ex 3
print("Just a young gun with a quick fuse  I was uptight, wanna let loose I was dreaming of bigger things and Wanna leave my own life behind Not a Yes, sir, not a follower Fit the box, fit the mold, have a seat In the foyer, take a number I was lightning before the thunder, thunder")
#ex 4

texto ="eu joao gosto muito de voce"

print("Enviando mensagem:", texto)

desculpa="Desconsidera foi um hacker"

print(desculpa)

#ex 5

print("Entrar na área")

#ex 6

quadrado=" XXXXX\n X    X\n X    X\n X    X\n X    X\n XXXXX"
print(quadrado)

#ex 7

print("ALUNO(A) NOTA\n========= =====\n ALINE  9.0 \nMÁRIO  DEZ\n SÉRGIO  4.5\n SHIRLEY  7.0"
)

#ex 8

print("EEEEE \nE \nEEE\nE\nEEEEE\n ")

#ex 9

menu= "0-fim \n 1-inclui \n 2-Altera \n 3-exlcui"
print(menu)

#ex 10

pinheiro="       X\n      XXX\n     XXXX\n    XXXOXXX\n   XXXXOXXXX\n  XXXXXXXXXXX\n XXXXXOXXXXXXX\nXXXXXXXXXXXOXXX\n       XX\n       XX\n      XXXX\n"

print(pinheiro)

